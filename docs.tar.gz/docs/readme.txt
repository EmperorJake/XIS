====================================
FIRS Industry Replacement Set 0.0
====================================
New Industries and Cargos for OpenTTD

FIRS docs are published online:
  http://bundles.openttdcoop.org/firs/releases/LATEST/docs

=======
GRF Name : FIRS Industry Replacement Set

This version of FIRS is created using repository version 0.0

Thanks to *all* who helped create FIRS.

------------
FIRS License
------------
FIRS Industry Replacement Set - Full industry replacement set for OpenTTD
Copyright (C) andythenorth, and others.

Licensed under GPL(v2)
  http://www.gnu.org/licenses/gpl-2.0.html

----------------
License Exceptions
----------------
All assets within the project required to produce the grf (program) are GPL(v2) or GPL(v2)-compatible.

Copying, redistribution or modification of these assets must be GPL(v2) compliant.

Some assets which are optional for producing the grf use free software licenses that are not GPL(v2) compatible.

Copying, redistribution or modification of these assets must be compliant with their respective licenses.

Bootstrap is used to produce HTML documentation and is licensed under the MIT License.
    https://github.com/twbs/bootstrap/blob/master/LICENSE
GPL-compatibility notes for HTML templates:
    https://www.gnu.org/licenses/old-licenses/gpl-2.0-faq.en.html#WMS

Silkscreen font is used for documentation, and is distributed under the Open Font License.
    http://www.kottke.org/plus/type/silkscreen/
GPL-compatibility notes for fonts:
    https://www.fsf.org/blogs/licensing/20050425novalis

